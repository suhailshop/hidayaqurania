
<pre dir="rtl" style="Float:right;"><strong>{{ $text }}</strong></pre>
