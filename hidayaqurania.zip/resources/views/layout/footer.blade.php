
 </div>



<!-- BEGIN FOOTER -->
<div class="page-footer" >

    <div class="page-footer-inner" >  جميع الحقوق محفوظة لموسوعة الهدايات القرآنية &copy; <?php echo date('Y'); ?>

          <div class="scroll-to-top">
            <i class="icon-arrow-up" style="color: #8b7005"></i>
          </div>

    </div>

    <div class="btn-group   btn-group-sm pull-right ">

        <a type="button" class="btn red" href="https://wa.me/966506087020" target="_blank">فضلا راسلنا لاي مشكلة فنية </a>

    </div>


</div>







<!-- END FOOTER -->






<!--[if lt IE 9]>
<script src="{!! asset('assets/global/plugins/respond.min.js') !!}"></script>
<script src="{!! asset('assets/global/plugins/excanvas.min.js') !!}"></script>
<script src="{!! asset('assets/global/plugins/ie8.fix.min.js') !!}"></script>
<![endif]-->





<!-- BEGIN CORE PLUGINS -->
<script src="{!! asset('assets/global/plugins/jquery.min.js') !!}" type="text/javascript"></script>
<script src="{!! asset('assets/global/plugins/bootstrap/js/bootstrap.min.js') !!}" type="text/javascript"></script>
<script src="{!! asset('assets/global/plugins/js.cookie.min.js') !!}" type="text/javascript"></script>
<script src="{!! asset('assets/global/plugins/jquery-slimscroll/jquery.slimscroll.min.js') !!}" type="text/javascript"></script>
<script src="{!! asset('assets/global/plugins/jquery.blockui.min.js') !!}" type="text/javascript"></script>
<script src="{!! asset('assets/global/plugins/bootstrap-switch/js/bootstrap-switch.min.js') !!}" type="text/javascript"></script>
<!-- END CORE PLUGINS -->


<!-- BEGIN THEME GLOBAL SCRIPTS -->
<script src="{!! asset('assets/global/scripts/app.min.js') !!}" type="text/javascript"></script>
<!-- END THEME GLOBAL SCRIPTS -->


<!-- BEGIN THEME LAYOUT SCRIPTS -->
<script src="{!! asset('assets/layouts/layout2/scripts/layout.min.js') !!}" type="text/javascript"></script>
<script src="{!! asset('assets/layouts/global/scripts/quick-sidebar.min.js') !!}" type="text/javascript"></script>
<!-- END THEME LAYOUT SCRIPTS -->

@yield('pageScript')
</body>

</html>