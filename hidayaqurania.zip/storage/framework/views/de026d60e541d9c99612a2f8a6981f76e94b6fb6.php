<?php $__env->startSection('pageTitle', 'تقاريري'); ?>
<?php $__env->startSection('pageStyle'); ?>
    
    <!-- BEGIN PAGE LEVEL PLUGINS -->
    <link href="<?php echo asset('assets/global/plugins/datatables/datatables.min.css'); ?>" rel="stylesheet" type="text/css" />
    <link href="<?php echo asset('assets/global/plugins/datatables/plugins/bootstrap/datatables.bootstrap-rtl.css'); ?>" rel="stylesheet" type="text/css" />
    <!-- END PAGE LEVEL PLUGINS -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('pageTitle', 'الرئيسية'); ?>


<?php $__env->startSection('content'); ?>

    <!-- BEGIN CONTENT -->
    <div class="page-content-wrapper">
        <!-- BEGIN CONTENT BODY -->
        <div class="page-content">
            <!-- BEGIN PAGE HEADER-->


            <h1 class="page-title"> البوابة الالكترونية لموسوعة الهدايات القرآنية

            </h1>
            <div class="page-bar">
                <ul class="page-breadcrumb">
                    <li>
                        <i class="icon-home"></i>
                    <a href="<?php echo e(route('portalwelcome')); ?>">الرئيسية</a>
                        <i class="fa fa-angle-left"></i>
                    </li>
                    <li>
                            <i class="icon-chemistry"></i>
                        <span>ادارة تقاريري</span>
                    </li>
                </ul>
            </div>
            <!-- END PAGE HEADER-->

         
            <div class="row">
            <div class="col-md-12">
                <!-- BEGIN EXAMPLE TABLE PORTLET-->
                <div class="portlet light ">
                    <div class="portlet-title">
                        <div class="caption font-dark">
                            <i class="icon-graduation font-dark"></i>
                            <span class="caption-subject bold uppercase">لائحة التقارير الخاصة بي  </span>
                        </div>
                        <div class="tools"> </div>
                    </div>
                    <div class="portlet-body">
                        <table class="table table-striped table-bordered table-hover dt-responsive" width="100%" id="sample_1">
                            <thead>
                                <tr>
                                    <th class="all">الصنف</th>
                                    <th class="all">القسم</th>
                                    <th class="all">التاريخ</th>
                                    <th class="none"> تقييم الجزء المنجز</th>
                                    <th class="none">عدد الجلسات</th>
                                    <th class="none">مجموع ساعات الاشراف</th>
                                    <th class="none">مدى الالتزام بالتعديلات</th>
                                    <th class="none">تاريخ الاعتماد</th>
                                    <th class="none">الاسباب</th>
                                    <th class="none">الصعوبات</th>
                                    <th class="none">الملاحظات</th>
                                    <th class="all">التحميل</th>
                                    <th class="all">تقرير الادارة</th>
                                    <th class="none">الحالة</th>
                                    <th class="all">خيارات.</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $reports; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $report): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($report->TypeCyclic); ?></td>
                                    <td><?php echo e($report->section->Name); ?></td>
                                    <td><?php echo e($report->DateSearcher); ?></td>
                                    <td><?php echo e($report->DoneRange); ?></td>
                                    <td><?php echo e($report->SessionsCount); ?></td>
                                    <td><?php echo e($report->HoursNumber); ?></td>
                                    <td><?php echo e($report->UpdatedRange); ?></td>
                                    <td><?php echo e($report->DateCommittee); ?></td>
                                    <td><?php echo e($report->Reasons); ?></td>
                                    <td><?php echo e($report->Difficulties); ?></td>
                                    <td><?php echo e($report->Notes); ?></td>
                                    <td>
                                        <a href="<?php echo e(url('storage/searchersreports/'.$report->URL)); ?>" >تحميل</a>
                                    </td>
                                    <td>
                                    <?php if(isset($report->committesreport) ): ?>
                                        <button type="button" class="btn green" data-toggle="modal" data-target="#exampleModal">مشاهدة</button>
                                        <!-- Modal -->
                                        <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                            <div class="modal-dialog" role="document">
                                            <div class="modal-content">
                                                <div class="modal-header">
                                                <h5 class="modal-title" id="exampleModalLabel">تقرير الادارة </h5>
                                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                    <span aria-hidden="true">&times;</span>
                                                </button>
                                                </div>
                                                <div class="modal-body">
                                                        <div class="panel-group accordion" id="accordion1">
                                                                <div class="panel panel-default">
                                                                    <div class="panel-heading">
                                                                        <h4 class="panel-title">
                                                                            <a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion1" href="#collapse_1"> تحميل الملف : </a>
                                                                        </h4>
                                                                    </div>
                                                                    <div id="collapse_1" class="panel-collapse in">
                                                                        <div class="panel-body">
                                                                            <p><a class="btn red" href="<?php echo e(url('storage/adminreports/'.$report->committesreport->URL)); ?>"  target="_blank">تحميل </a></p>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div class="panel panel-default">
                                                                    <div class="panel-heading">
                                                                        <h4 class="panel-title">
                                                                            <a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion1" href="#collapse_2"> القسم : </a>
                                                                        </h4>
                                                                    </div>
                                                                    <div id="collapse_2" class="panel-collapse collapse">
                                                                        <div class="panel-body" style=" overflow-y:auto;">
                                                                            <p> <?php echo e($report->committesreport->section->Name); ?> </p>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div class="panel panel-default">
                                                                        <div class="panel-heading">
                                                                            <h4 class="panel-title">
                                                                                <a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion1" href="#collapse_5"> اللجنة : </a>
                                                                            </h4>
                                                                        </div>
                                                                        <div id="collapse_5" class="panel-collapse collapse">
                                                                            <div class="panel-body" style=" overflow-y:auto;">
                                                                                <p> الاسم العائلي : <?php echo e($report->committesreport->committee->FirstName); ?> </p>
                                                                                <p>الاسم الشخصي : <?php echo e($report->committesreport->committee->LastName); ?></p>
                                                                                <p>الجنس : <?php echo e($report->committesreport->committee->Gender); ?></p>
                                                                                <p>المهمة : <?php echo e($report->committesreport->committee->Function); ?></p>                                                                               

                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                <div class="panel panel-default">
                                                                    <div class="panel-heading">
                                                                        <h4 class="panel-title">
                                                                            <a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion1" href="#collapse_3">  التقييم : </a>
                                                                        </h4>
                                                                    </div>
                                                                    <div id="collapse_3" class="panel-collapse collapse">
                                                                        <div class="panel-body">
                                                                            <p> تقييم الجزء المنجز : <?php echo e($report->committesreport->DoneRange); ?> </p>
                                                                            <p> مدى التقدم الحالي : <?php echo e($report->committesreport->CurrentProgress); ?> </p>
                                                                            <p>مدى الالتزام بتوجيهات اللجنة : <?php echo e($report->committesreport->QualityDirection); ?> </p>
                                                                            <p>رأي اللجنة : <?php echo e($report->committesreport->Recommendations); ?></p>
                                                                            <p>الجزء المنجز : <?php echo e($report->committesreport->UpdatedRange); ?></p>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div class="panel panel-default">
                                                                    <div class="panel-heading">
                                                                        <h4 class="panel-title">
                                                                            <a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion1" href="#collapse_4"> معلومات أخرى : </a>
                                                                        </h4>
                                                                    </div>
                                                                    <div id="collapse_4" class="panel-collapse collapse">
                                                                        <div class="panel-body">
                                                                            <p> أسباب عدم القبول : <?php echo e($report->committesreport->Reasons); ?> </p>
                                                                            <p> تاريخ الاعتماد : <?php echo e($report->committesreport->DateCommittee); ?> </p>
                                                                            <p>  رئيس اللجنة العلمية : <?php echo e($report->committesreport->President); ?><p>
                                                                            <p> اعتماد استاذ الكرسي : <?php echo e($report->committesreport->Professor); ?>  </p>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>



                                                        
                                                </div>
                                                <div class="modal-footer">
                                                <button type="button" class="btn btn-info" data-dismiss="modal">اغلاق</button>
                                                </div>
                                            </div>
                                            </div>
                                        </div>
                                    <?php else: ?> 
                                    <button type="button" class="btn red" > لا تقرير</button>                                      
                                    <?php endif; ?>
                                    </td>
                                    <td><?php if($report->Status == 'yes'): ?> مفعلة <?php else: ?> غير مفعلة <?php endif; ?></td>
                                    <td>
                                        <div class="btn-group pull-right">
                                            <button class="btn green btn-xs btn-outline dropdown-toggle" data-toggle="dropdown">اختر
                                                <i class="fa fa-angle-down"></i>
                                            </button>
                                            <ul class="dropdown-menu pull-right">
                                                <li>
                                                <a href="<?php echo e(route('editSearcherReport',['id'=>$report->ID])); ?>">
                                                        <i class="fa fa-edit"></i> تعديل </a>
                                                </li>
                                                <li>
                                                <a data-toggle="confirmation"
                                                data-btn-ok-label="نعم" data-btn-ok-class="btn-success"
                                                data-btn-ok-icon-class="material-icons" data-btn-ok-icon-content="check"
                                                data-btn-cancel-label="لا" data-btn-cancel-class="btn-danger"
                                                data-btn-cancel-icon-class="material-icons" data-btn-cancel-icon-content="close"
                                                data-title="هل تريد الحذف ؟" href="<?php echo e(route('deleteSearcherReport',['id'=>$report->ID])); ?>">
                                                        <i class="fa fa-remove"></i> حذف </a>
                                                </li>

                                            </ul>
                                        </div>
                                        
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>


        </div>
</div>
        <!-- END CONTENT BODY -->
    </div>
    <!-- END CONTENT -->
    <?php $__env->startSection('pageScript'); ?>
        <!-- BEGIN PAGE LEVEL PLUGINS -->
        <script src="<?php echo asset('assets/global/scripts/datatable.js'); ?>" type="text/javascript"></script>
        <script src="<?php echo asset('assets/global/plugins/datatables/datatables.min.js'); ?>" type="text/javascript"></script>
        <script src="<?php echo asset('assets/global/plugins/datatables/plugins/bootstrap/datatables.bootstrap.js'); ?>" type="text/javascript"></script>
         <script src="<?php echo asset('assets/pages/scripts/table-datatables-responsive.min.js'); ?>" type="text/javascript"></script>

        <!-- END PAGE LEVEL PLUGINS -->
    <?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>