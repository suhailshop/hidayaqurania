<?php $__env->startSection('pageTitle', 'الرئيسية'); ?>
<?php $__env->startSection('pageStyle'); ?>
    
<?php $__env->stopSection(); ?>



<?php $__env->startSection('content'); ?>

    <!-- BEGIN CONTENT -->
    <div class="page-content-wrapper">
        <!-- BEGIN CONTENT BODY -->
        <div class="page-content">
            <!-- BEGIN PAGE HEADER-->

            <div class="page-bar">
                <ul class="page-breadcrumb">
                    <li>
                        <i class="icon-home"></i>
                      الرئيسية
                    </li>
                </ul>
            </div>
            <!-- END PAGE HEADER-->


            <?php if(auth()->user()->hasRole('admin',auth()->user()->role_id)): ?>
            <div class="row">
                <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
                <a class="dashboard-stat dashboard-stat-v2 blue" href="<?php echo e(route('allSearcher')); ?>">
                        <div class="visual">
                            <i class="fa fa-users"></i>
                        </div>
                        <div class="details">
                            <div class="number">
                                <span data-counter="counterup" data-value="<?php echo e(count($searchers)); ?>"><?php echo e(count($searchers)); ?></span>
                            </div>
                            <div class="desc"> الطلاب </div>
                        </div>
                    </a>
                </div>
                <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
                    <a class="dashboard-stat dashboard-stat-v2 red" href="<?php echo e(route('allSupervisor')); ?>">
                        <div class="visual">
                            <i class="fa fa-briefcase"></i>
                        </div>
                        <div class="details">
                            <div class="number">
                            <span data-counter="counterup" data-value="<?php echo e(count($supervisors)); ?>"><?php echo e(count($supervisors)); ?></span></div>
                            <div class="desc"> المشرفين </div>
                        </div>
                    </a>
                </div>
                <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
                    <a class="dashboard-stat dashboard-stat-v2 green" href="<?php echo e(route('allUniversity')); ?>">
                        <div class="visual">
                            <i class="fa fa-graduation-cap"></i>
                        </div>
                        <div class="details">
                            <div class="number">
                                <span data-counter="counterup" data-value="<?php echo e(count($universities)); ?>"><?php echo e(count($universities)); ?></span>
                            </div>
                            <div class="desc"> الجامعات </div>
                        </div>
                    </a>
                </div>
                <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
                    <a class="dashboard-stat dashboard-stat-v2 purple" href="<?php echo e(route('allCountrie')); ?>">
                        <div class="visual">
                            <i class="fa fa-globe"></i>
                        </div>
                        <div class="details">
                            <div class="number"> 
                                <span data-counter="counterup" data-value="<?php echo e(count($countries)); ?>"><?php echo e(count($countries)); ?></span> </div>
                            <div class="desc"> الدول </div>
                        </div>
                    </a>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
                <a class="dashboard-stat dashboard-stat-v2 grey-mint" href="<?php echo e(route('allProvide')); ?>">
                        <div class="visual">
                            <i class="fa fa-certificate"></i>
                        </div>
                        <div class="details">
                            <div class="number">
                                <span data-counter="counterup" data-value="<?php echo e(count($provides)); ?>"><?php echo e(count($provides)); ?></span>
                            </div>
                            <div class="desc"> التزويدات </div>
                        </div>
                    </a>
                </div>
                <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
                    <a class="dashboard-stat dashboard-stat-v2 green-haze " href="<?php echo e(route('allBook')); ?>">
                        <div class="visual">
                            <i class="fa fa-book"></i>
                        </div>
                        <div class="details">
                            <div class="number">
                            <span data-counter="counterup" data-value="<?php echo e(count($books)); ?>"><?php echo e(count($books)); ?></span></div>
                            <div class="desc"> الكتب </div>
                        </div>
                    </a>
                </div>
                <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
                    <a class="dashboard-stat dashboard-stat-v2 purple-plum" href="<?php echo e(route('allThese')); ?>">
                        <div class="visual">
                            <i class="fa fa-comments"></i>
                        </div>
                        <div class="details">
                            <div class="number">
                                <span data-counter="counterup" data-value="<?php echo e(count($theses)); ?>"><?php echo e(count($theses)); ?></span>
                            </div>
                            <div class="desc"> الاطروحات </div>
                        </div>
                    </a>
                </div>
                <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
                    <a class="dashboard-stat dashboard-stat-v2 yellow" href="<?php echo e(route('allHelp')); ?>">
                        <div class="visual">
                            <i class="fa fa-credit-card"></i>
                        </div>
                        <div class="details">
                            <div class="number"> 
                                <span data-counter="counterup" data-value="<?php echo e($helps); ?>"><?php echo e($helps); ?></span> </div>
                            <div class="desc"> المساعدات </div>
                        </div>
                    </a>
                </div>
            </div>
            <div class="row">
                    <div class="col-lg-12 col-xs-12 col-sm-12">
                        <div class="portlet light ">
                            <div class="portlet-title tabbable-line">
                                <div class="caption">
                                    <i class="icon-bubbles font-dark hide"></i>
                                    <span class="caption-subject font-dark bold uppercase">اخر تسجيلات الطلاب </span>
                                </div>
                            </div>
                            <div class="portlet-body">
                                <div class="tab-content">
                                    <div class="tab-pane active" id="portlet_comments_1">
                                        <!-- BEGIN: Comments -->
                                        <div class="mt-comments">
                                            <?php $__currentLoopData = $lastsearchers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $searcher): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <div class="mt-comment">
                                                <div class="mt-comment-img">
                                                    <img width="45px" height="45px"  src="<?php echo e(url('storage/registrations/'.$searcher->PictureURL)); ?>" /> </div>
                                                <div class="mt-comment-body">
                                                    <div class="mt-comment-info">
                                                    <span class="mt-comment-author"><?php echo e($searcher->LastName); ?> <?php echo e($searcher->Fistname); ?> </span>
                                                        <span class="mt-comment-date"><?php echo e($searcher->created_at); ?></span>
                                                    </div>
                                                    <div class="mt-comment-text"> <?php echo e($searcher->Location); ?> , <?php echo e($searcher->City); ?> </div>
                                                    <div class="mt-comment-details">
                                                        <span class="mt-comment-status mt-comment-status-pending"><?php echo e($searcher->Gender); ?></span>
                                                        <ul class="mt-comment-actions">
                                                            <li>
                                                            <a href="<?php echo e(route('getSearcher',['id'=>$searcher->ID])); ?>">معلومات الباحث</a>
                                                            </li>
                                                        </ul>
                                                    </div>
                                                </div>
                                            </div>   
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                                       
                                        </div>
                                        <!-- END: Comments -->
                                    </div>
                                
                                </div>
                            </div>
                        </div>
                    </div>
                  
                </div>
            <?php elseif(auth()->user()->hasRole('supervisor',auth()->user()->role_id)): ?>


                <!--  حساب المشرف هنا -->

                <div class="largeText" style="font-weight: normal; font-size: large">
                    <p> <i class="fa fa-angle-double-left "></i> ملخص الحساب الخاص بي : </p>
                </div>

                <div class="row">
                    <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
                        <a class="dashboard-stat dashboard-stat-v2 blue" href="#">
                            <div class="visual">
                                <i class="fa fa-users"></i>
                            </div>
                            <div class="details">
                                <div class="number">
                                    <span data-counter="counterup" data-value="4">4</span>
                                </div>
                                <div class="desc"> عدد الطلاب تحت إشرافي </div>
                            </div>
                        </a>
                    </div>
                    <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
                        <a class="dashboard-stat dashboard-stat-v2 red" href="#">
                            <div class="visual">
                                <i class="fa fa-briefcase"></i>
                            </div>
                            <div class="details">
                                <div class="number">
                                    <span data-counter="counterup" data-value="6">6</span></div>
                                <div class="desc"> التقارير الإشرافية </div>
                            </div>
                        </a>
                    </div>
                    <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
                        <a class="dashboard-stat dashboard-stat-v2 green" href="#">
                            <div class="visual">
                                <i class="fa fa-graduation-cap"></i>
                            </div>
                            <div class="details">
                                <div class="number">
                                    <span data-counter="counterup" data-value="<?php echo e(count($books)); ?>"><?php echo e(count($books)); ?></span>
                                </div>
                                <div class="desc">المصادر التعليمية </div>
                            </div>
                        </a>
                    </div>
                    <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
                        <a class="dashboard-stat dashboard-stat-v2 purple" href="#">
                            <div class="visual">
                                <i class="fa fa-globe"></i>
                            </div>
                            <div class="details">
                                <div class="number">
                                    <span data-counter="counterup" data-value="7">7</span> </div>
                                <div class="desc">  تقارير الإدارة </div>
                            </div>
                        </a>
                    </div>
                </div>




            <?php elseif(auth()->user()->hasRole('student',auth()->user()->role_id)): ?>


            <div class="largeText" style="font-weight: normal; font-size: large">
                <p> <i class="fa fa-angle-double-left "></i> ملخص الحساب الخاص بي : </p>
            </div>

            <div class="row">
                <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
                    <a class="dashboard-stat dashboard-stat-v2 blue" href="<?php echo e(route('allSearchs')); ?>">
                        <div class="visual">
                            <i class="fa fa-users"></i>
                        </div>
                        <div class="details">
                            <div class="number">
                                <span data-counter="counterup" data-value="<?php echo e(count($searchs)); ?>"><?php echo e(count($searchs)); ?></span>
                            </div>
                            <div class="desc">  الأجزاء البحثية </div>
                        </div>
                    </a>
                </div>
                <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
                    <a class="dashboard-stat dashboard-stat-v2 red" href="<?php echo e(route('allSearcherReports')); ?>">
                        <div class="visual">
                            <i class="fa fa-briefcase"></i>
                        </div>
                        <div class="details">
                            <div class="number">
                                <span data-counter="counterup" data-value="<?php echo e(count($myreports)); ?>"><?php echo e(count($myreports)); ?></span></div>
                            <div class="desc"> التقارير الدورية </div>
                        </div>
                    </a>
                </div>
                <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
                    <a class="dashboard-stat dashboard-stat-v2 green" href="<?php echo e(route('allbookssearcher')); ?>">
                        <div class="visual">
                            <i class="fa fa-graduation-cap"></i>
                        </div>
                        <div class="details">
                            <div class="number">
                                <span data-counter="counterup" data-value="<?php echo e(count($books)); ?>"><?php echo e(count($books)); ?></span>
                            </div>
                            <div class="desc">المصادر التعليمية </div>
                        </div>
                    </a>
                </div>
                <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
                    <a class="dashboard-stat dashboard-stat-v2 purple" href="#">
                        <div class="visual">
                            <i class="fa fa-globe"></i>
                        </div>
                        <div class="details">
                            <div class="number">
                                <span data-counter="counterup" data-value="<?php echo e($admin_reports); ?>"><?php echo e($admin_reports); ?></span> </div>
                            <div class="desc">  تقارير الإدارة </div>
                        </div>
                    </a>
                </div>
            </div>


            <div class="largeText" style="font-weight: normal; font-size: large">
                <p><i class="fa fa-angle-double-left "></i> مخطط البحث الخاص بي : </p>
            </div>


            <div class="portlet light portlet-fit ">
                <div class="portlet-body">
                    <div class="mt-element-list">
                        <div class="mt-list-head list-todo yellow">
                            <div class="list-head-title-container">

                                <!-- هنا يتم استبدال اسم السورة حسب عنوان البحث الخاص بكل طالب، فمثلا هذا الطالب عنوان البحث الخاص به عن سورة الأنفال  -->
                                <h4 class="list-title myfont">  عنوان البحث : <?php echo e($these_name); ?>

                                </h4>

                            </div>

                        </div>
                        <div class="mt-list-container list-todo">
                            <div class="list-todo-line"></div>
                            <ul>

                                <!-- القسم الأول  -->
                                <?php $__currentLoopData = $sections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $section): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li class="mt-list-item">
                                    <div class="list-todo-icon bg-white">
                                        <i class="fa fa-book"></i>
                                    </div>
                                    <div class="list-todo-item grey">
                                    <a class="list-toggle-container font-white collapsed" data-toggle="collapse" href="#section<?php echo e($section->ID); ?>" aria-expanded="false">
                                            <div class="list-toggle done uppercase">
                                            <div class="list-toggle-title "><?php echo e($section->Name); ?></div>
                                                <div class="badge badge-info pull-right bold">الفصول : <?php echo e(count($section->divisions)); ?></div>
                                            </div>
                                        </a>
                                        <div class="task-list panel-collapse collapse" id="section<?php echo e($section->ID); ?>" aria-expanded="false" style="height: 0px;">
                                            <ul>

                                               <!--  الفصل الأول  -->
                                               <?php $__currentLoopData = $section->divisions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $divs): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                                <li class="task-list-item">
                                                    <div class="task-icon">
                                                        <a href="javascript:;">
                                                            <i class="fa fa-sticky-note-o"></i>
                                                        </a>
                                                    </div>
                                                    <div class="task-status">
                                                            <?php if(count($divs->divisionunit) <= count($divs->searchs)): ?>
                                                           
                                                            <span class="badge badge-success"> تم إكمال الفصل </span>
                                                            <?php else: ?>
                                                            <span class="badge badge-danger"> الفصل لم يكتمل بعد</span>
                                                          
                                                            <?php endif; ?>
                                                             
                                                    </div>
                                                    <div class="task-content">
                                                        <h4 class="uppercase bold myfont">
                                                            <a class="list-toggle-container collapsed" data-toggle="collapse"  href="#section1data<?php echo e($divs->ID); ?>" aria-expanded="false">  <?php echo e($divs->Name); ?></a>
                                                        </h4>


                                                        <div class="mt-list-container list-simple ext-1 group">
                                                            <div class="panel-collapse collapse" id="section1data<?php echo e($divs->ID); ?>" aria-expanded="false" style="height: 0px;">
                                                                <ul>

                                                                    <?php $__currentLoopData = $divs->searchs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $search): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                    <li class="mt-list-item">
                                                                        <div class="list-icon-container">
                                                                            <span class="badge badge-warning"> <?php echo e($search->Progress); ?></span>
                                                                        </div>

                                                                        <div class="list-item-content">
                                                                            <h5 class="uppercase myfont">
                                                                            <a href="<?php echo e(url('storage/searchs/'.$search->SearchURL)); ?>" target="newtab"><?php echo e($search->divisionunit->Name); ?></a>
                                                                            </h5>
                                                                        </div>
                                                                    </li>

                                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                                                  

                                                                    <br>
                                                                 </ul>
                                                            </div>
                                                        </div>
                                                    </div>


                                                </li>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            

                                             </ul>
                                            <div class="task-footer bg-grey">

                                            </div>
                                        </div>
                                    </div>
                                </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                             </ul>
                        </div>
                    </div>
                </div>
            </div>


            <?php endif; ?>
        </div>
        <!-- END CONTENT BODY -->
    </div>
    <!-- END CONTENT -->
    <?php $__env->startSection('pageScript'); ?>
    <script src="<?php echo asset('assets/global/plugins/counterup/jquery.waypoints.min.js'); ?>" type="text/javascript"></script>
    <script src="<?php echo asset('assets/global/plugins/counterup/jquery.counterup.min.js'); ?>" type="text/javascript"></script>
   
        <script src="<?php echo asset('assets/pages/scripts/dashboard.min.js'); ?>" type="text/javascript"></script>
    <?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>