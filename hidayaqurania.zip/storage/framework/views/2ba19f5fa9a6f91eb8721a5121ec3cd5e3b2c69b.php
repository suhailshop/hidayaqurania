<?php $__env->startSection('pageTitle', 'البحوث'); ?>
<?php $__env->startSection('pageStyle'); ?>
    
    <!-- BEGIN PAGE LEVEL PLUGINS -->
    <link href="<?php echo asset('assets/global/plugins/datatables/datatables.min.css'); ?>" rel="stylesheet" type="text/css" />
    <link href="<?php echo asset('assets/global/plugins/datatables/plugins/bootstrap/datatables.bootstrap-rtl.css'); ?>" rel="stylesheet" type="text/css" />
    <!-- END PAGE LEVEL PLUGINS -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('pageTitle', 'الرئيسية'); ?>


<?php $__env->startSection('content'); ?>

    <!-- BEGIN CONTENT -->
    <div class="page-content-wrapper">
        <!-- BEGIN CONTENT BODY -->
        <div class="page-content">
            <!-- BEGIN PAGE HEADER-->


            <h1 class="page-title"> البوابة الالكترونية لموسوعة الهدايات القرآنية

            </h1>
            <div class="page-bar">
                <ul class="page-breadcrumb">
                    <li>
                        <i class="icon-home"></i>
                    <a href="<?php echo e(route('portalwelcome')); ?>">الرئيسية</a>
                        <i class="fa fa-angle-left"></i>
                    </li>
                    <li>
                            <i class="icon-chemistry"></i>
                        <span>ادارة البحوث</span>
                    </li>
                </ul>
            </div>
            <!-- END PAGE HEADER-->

         
            <div class="row">
            <div class="col-md-12">
                <!-- BEGIN EXAMPLE TABLE PORTLET-->
                <div class="portlet light ">
                    <div class="portlet-title">
                        <div class="caption font-dark">
                            <i class="icon-graduation font-dark"></i>
                            <span class="caption-subject bold uppercase">لائحة البحوث بالنظام  </span>
                        </div>
                        <div class="tools"> </div>
                    </div>
                    <div class="portlet-body">
                        <table class="table table-striped table-bordered table-hover dt-responsive" width="100%" id="sample_1">
                            <thead>
                                <tr>
                                    
                                    <th class="all">الاسم</th>
                                    <th class="none">الاختصار</th>
                                    <th class="all">القسم</th>
                                    <th class="all">المبحث</th>
                                    <th class="all">الباحث</th>
                                    <th class="none"> الترتيب</th>
                                    <th class="all">الملف</th>
                                    <th class="all">الحالة</th>
                                    <th class="all">خيارات.</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $searchs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $search): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    
                                    <td><?php echo e($search->Name); ?></td>
                                    <td><?php echo e($search->Alias); ?></td>
                                    <td><?php echo e($search->division->Name); ?></td>
                                    <td><?php echo e($search->divisionunit->Name); ?></td>
                                    <td><?php echo e($search->searcher->Fistname); ?> <?php echo e($search->searcher->LastName); ?></td>
                                    <td><?php echo e($search->Order); ?></td>
                                    <td>
                                        <a href="<?php echo e(url('storage/searchs/'.$search->SearchURL)); ?>" >تحميل</a>
                                    </td>
                                    <td>  <?php if($search->Progress=='تم الرفع'): ?> 
                                        <span class="badge badge-warning"><?php echo e($search->Progress); ?></span>
                                        <?php elseif($search->Progress=='رفض الادارة' || $search->Progress=='رفض المشرف' ): ?> 
                                        <span class="badge badge-danger"><?php echo e($search->Progress); ?></span>
                                        <?php elseif($search->Progress=='موافقة المشرف' || $search->Progress=='موافقة الادارة' ): ?> 
                                        <span class="badge badge-success"><?php echo e($search->Progress); ?></span>
                                        <?php endif; ?>                                    
                                    </td>
                                    <td>
                                        <div class="btn-group pull-right">
                                            <button class="btn green btn-xs btn-outline dropdown-toggle" data-toggle="dropdown">اختر
                                                <i class="fa fa-angle-down"></i>
                                            </button>
                                            <ul class="dropdown-menu pull-right">
                                              
                                                <li>
                                                <a data-toggle="confirmation"
                                                data-btn-ok-label="نعم" data-btn-ok-class="btn-success"
                                                data-btn-ok-icon-class="material-icons" data-btn-ok-icon-content="check"
                                                data-btn-cancel-label="لا" data-btn-cancel-class="btn-danger"
                                                data-btn-cancel-icon-class="material-icons" data-btn-cancel-icon-content="close"
                                                data-title="هل تريد الموافقة ؟" href="<?php echo e(route('updateProgressok',['id'=>$search->ID])); ?>">
                                                        <i class="fa fa-check"></i> موافقة الادارة </a>
                                                </li>
                                                <li>
                                                        <a data-toggle="confirmation"
                                                        data-btn-ok-label="نعم" data-btn-ok-class="btn-success"
                                                        data-btn-ok-icon-class="material-icons" data-btn-ok-icon-content="check"
                                                        data-btn-cancel-label="لا" data-btn-cancel-class="btn-danger"
                                                        data-btn-cancel-icon-class="material-icons" data-btn-cancel-icon-content="close"
                                                        data-title="هل تريد الرفض ؟" href="<?php echo e(route('updateProgressko',['id'=>$search->ID])); ?>">
                                                                <i class="fa fa-close"></i> رفض الادارة </a>
                                                        </li>

                                            </ul>
                                        </div>
                                        
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>


        </div>
</div>
        <!-- END CONTENT BODY -->
    </div>
    <!-- END CONTENT -->
    <?php $__env->startSection('pageScript'); ?>
        <!-- BEGIN PAGE LEVEL PLUGINS -->
        <script src="<?php echo asset('assets/global/scripts/datatable.js'); ?>" type="text/javascript"></script>
        <script src="<?php echo asset('assets/global/plugins/datatables/datatables.min.js'); ?>" type="text/javascript"></script>
        <script src="<?php echo asset('assets/global/plugins/datatables/plugins/bootstrap/datatables.bootstrap.js'); ?>" type="text/javascript"></script>
         <script src="<?php echo asset('assets/pages/scripts/table-datatables-responsive.min.js'); ?>" type="text/javascript"></script>

        <!-- END PAGE LEVEL PLUGINS -->
    <?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>