<!doctype html>
<html lang="<?php echo e(app()->getLocale()); ?>">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
<link href="<?php echo e(URL::asset('template/css/bootstrap.css')); ?>" rel="stylesheet" type="text/css">
	
        <title>Laravel</title>

        <!-- Fonts -->
        <link href="https://fonts.googleapis.com/css?family=Raleway:100,600" rel="stylesheet" type="text/css">


    </head>
    <body>
    <section class="content"  >

         

          <div class="row" >

          <div class="col-xs-2"></div>
          <div class="col-xs-8">
   <?php if($message = Session::get('success')): ?>
				<div class="alert alert-success alert-block col-md-11">
					<button type="button" class="close" data-dismiss="alert">×</button>
				        <strong><?php echo e($message); ?></strong>
				</div>
				<?php endif; ?>
				<br />
				<br />
				<br />
          <h1> لوحة التحكم</h1>
       <table class='table table-striped table-bordered bootstrap-datatable datatable' dir="rtl">

	
        	<thead>
        		<th>#</th>
        		<th>عنوان الخبر</th>
        		<th>تاريخ الاضافة</th>
        		<th>تاريخ التحديث</th>
        		<th colspan="2"> <a href="<?php echo e(url('/add')); ?>" class="btn btn-success">إضافة خبر جديد</a></th>
        	</thead>
        	<tbody>
        	<?php $__empty_1 = true; $__currentLoopData = $news; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $new): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        		<tr>
        			<td><?php echo e($new->id); ?></td>
        			<td><?php echo e($new->title); ?></td>
        			<td><?php echo e($new->created_at); ?></td>
        			<td><?php echo e($new->updated_at); ?></td>
        			<td><a href="<?php echo e(url('/edit/'.$new->id)); ?>"  >تعديل</a></td>
        			<td><a href="<?php echo e(url('/delete/'.$new->id)); ?>" onclick="return confirm('هل تريد حذف هذا الخبر ؟');"  >حذف</a></td>
        		</tr>
        	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                          
                          <?php endif; ?>   
                 	
        	</tbody>
        </table>
        </div>
        </div>
        </section>
    </body>
</html>
