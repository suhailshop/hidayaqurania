<?php $__env->startSection('pageTitle', 'الباحثين'); ?>
<?php $__env->startSection('pageStyle'); ?>
    
    <!-- BEGIN PAGE LEVEL PLUGINS -->
    <link href="<?php echo asset('assets/global/plugins/datatables/datatables.min.css'); ?>" rel="stylesheet" type="text/css" />
    <link href="<?php echo asset('assets/global/plugins/datatables/plugins/bootstrap/datatables.bootstrap-rtl.css'); ?>" rel="stylesheet" type="text/css" />
    <!-- END PAGE LEVEL PLUGINS -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('pageTitle', 'الرئيسية'); ?>


<?php $__env->startSection('content'); ?>

    <!-- BEGIN CONTENT -->
    <div class="page-content-wrapper">
        <!-- BEGIN CONTENT BODY -->
        <div class="page-content">
            <!-- BEGIN PAGE HEADER-->


            <h1 class="page-title"> البوابة الالكترونية لموسوعة الهدايات القرآنية

            </h1>
            <div class="page-bar">
                <ul class="page-breadcrumb">
                    <li>
                        <i class="icon-home"></i>
                    <a href="<?php echo e(route('portalwelcome')); ?>">الرئيسية</a>
                        <i class="fa fa-angle-left"></i>
                    </li>
                    <li>
                            <i class="icon-users"></i>
                        <span>إدارة طلبتي</span>
                    </li>
                </ul>
            </div>
            <!-- END PAGE HEADER-->

         
            <div class="row">
            <div class="col-md-12">
                <!-- BEGIN EXAMPLE TABLE PORTLET-->
                <div class="portlet light ">
                    <div class="portlet-title">
                        <div class="caption font-dark">
                            <i class="icon-graduation font-dark"></i>
                            <span class="caption-subject bold uppercase">لائحة الباحثين تحت اشرافي بالنظام</span>
                        </div>
                        <div class="tools"> </div>
                    </div>
                    <div class="portlet-body">
                        <table class="table table-striped table-bordered table-hover dt-responsive" width="100%" id="sample_1">
                            <thead>
                                <tr>
                                    <th class="min-phone-l">الاسم الكامل</th>
                                    <th class="none">الجنس</th>
                                    <th class="desc">تاريخ الازدياد</th>
                                    <th class="none">مكان الازدياد</th>
                                    <th class="desktop">الجنسية</th>
                                    <th class="none">الدولة</th>
                                    <th class="none">المدينة</th>
                                    <th class="none">العنوان</th>
                                    <th class="none">رقم جواز السفر</th>
                                    <th class="none">الرقم الوطني</th>
                                    <th class="none"> البريد الالكتروني </th>
                                    <th class="none"> الهاتف</th>
                                    <th class="none"> الجامعة</th>
                                    <th class="none">الكلية</th>
                                    <th class="none">الصورة</th>
                                    <th class="desktop">الاطروحة</th>
                                    <th class="desktop">الحالة</th>
                                    <th class="all">خيارات.</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $searchers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $searcher): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($searcher->Fistname); ?> <?php echo e($searcher->LastName); ?></td>
                                    <td><?php echo e($searcher->Gender); ?></td>
                                    <td><?php echo e($searcher->BirthDate); ?></td>
                                    <td><?php echo e($searcher->BirthCity); ?></td>
                                    <td><?php echo e($searcher->countrieName); ?></td>
                                    <td><?php echo e($searcher->nationalitieName); ?></td>
                                    <td><?php echo e($searcher->City); ?></td>
                                    <th><?php echo e($searcher->Location); ?></th>
                                    <td><?php echo e($searcher->PassportNumber); ?></td>
                                    <td><?php echo e($searcher->NationalNumber); ?></td>
                                    <td><?php echo e($searcher->Email); ?></td>
                                    <td><?php echo e($searcher->Phonne1); ?></td>
                                    <td><?php echo e($searcher->University); ?></td>
                                    <td><?php echo e($searcher->Faculty); ?></td>
                                    <td>
                                        <img src="<?php echo e(url('storage/registrations/'.$searcher->PictureURL)); ?>" 
                                            style="width: 39%;height: 39%;" class="img-responsive" alt=""> </div>
                                    </td>        
                                    
                                    <td><?php echo e($searcher->thesesTitle); ?></td>
                                    <td><?php if($searcher->Status == 'yes'): ?> مفعلة <?php else: ?> غير مفعلة <?php endif; ?></td>
                                    <td>
                                        <div class="btn-group pull-right">
                                            <button class="btn green btn-xs btn-outline dropdown-toggle" data-toggle="dropdown">اختر
                                                <i class="fa fa-angle-down"></i>
                                            </button>
                                            <ul class="dropdown-menu pull-right">
                                                <li>
                                                <a href="<?php echo e(route('getSearcherSearchs',['id'=>$searcher->ID])); ?>" >
                                                    <i class="fa fa-search-plus"></i> البحوث</a>
                                                </li>
                                                

                                            </ul>
                                        </div>
                                        
                                    </td>
                                </tr>
                                
                           
                            
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>


        </div>
</div>
        <!-- END CONTENT BODY -->
    </div>
    <!-- END CONTENT -->
    <?php $__env->startSection('pageScript'); ?>
        <!-- BEGIN PAGE LEVEL PLUGINS -->
        <script src="<?php echo asset('assets/global/scripts/datatable.js'); ?>" type="text/javascript"></script>
        <script src="<?php echo asset('assets/global/plugins/datatables/datatables.min.js'); ?>" type="text/javascript"></script>
        <script src="<?php echo asset('assets/global/plugins/datatables/plugins/bootstrap/datatables.bootstrap.js'); ?>" type="text/javascript"></script>
         <script src="<?php echo asset('assets/pages/scripts/table-datatables-responsive.min.js'); ?>" type="text/javascript"></script>
           
        <!-- END PAGE LEVEL PLUGINS -->
    <?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>