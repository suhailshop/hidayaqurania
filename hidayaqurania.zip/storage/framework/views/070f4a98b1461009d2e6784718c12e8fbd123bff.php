<?php $__env->startSection('pageTitle', 'البحوث'); ?>
<?php $__env->startSection('pageStyle'); ?>
    
    <!-- BEGIN PAGE LEVEL PLUGINS -->
    <link href="<?php echo asset('assets/global/plugins/datatables/datatables.min.css'); ?>" rel="stylesheet" type="text/css" />
    <link href="<?php echo asset('assets/global/plugins/datatables/plugins/bootstrap/datatables.bootstrap-rtl.css'); ?>" rel="stylesheet" type="text/css" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-multiselect/0.9.13/css/bootstrap-multiselect.css">
    
    <!-- END PAGE LEVEL PLUGINS -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('pageTitle', 'الرئيسية'); ?>


<?php $__env->startSection('content'); ?>

    <!-- BEGIN CONTENT -->
    <div class="page-content-wrapper">
        <!-- BEGIN CONTENT BODY -->
        <div class="page-content">
            <!-- BEGIN PAGE HEADER-->



            <div class="page-bar">
                <ul class="page-breadcrumb">
                    <li>
                        <i class="icon-home"></i>
                    <a href="<?php echo e(route('portalwelcome')); ?>">الرئيسية</a>
                        <i class="fa fa-angle-left"></i>
                    </li>
                    <li>
                            <i class="icon-chemistry"></i>
                        <span>ادارة البحوث</span>
                    </li>
                </ul>
            </div>
            <!-- END PAGE HEADER-->

         
            <div class="row">
            <div class="col-md-12">
                <!-- BEGIN EXAMPLE TABLE PORTLET-->
                <div class="portlet light ">
                    <div class="portlet-title">
                        <div class="caption font-dark">
                            <i class="icon-graduation font-dark"></i>
                            <span class="caption-subject bold uppercase">لائحة البحوث بالنظام  </span>
                        </div>
                        <div class="tools"> </div>
                    </div>
                    <div class="portlet-body">
                        <table class="table table-striped table-bordered table-hover dt-responsive" width="100%" id="sample_1">
                            <thead>
                                <tr>
                                    <th class="all">الرقم</th>
                                    <th class="all">الباحث</th>
                                    <th class="all">جزء البحث</th>
                                     <th class="all">القسم</th>


                                     <th class="all">الملف</th>

                                    <?php if(auth()->user()->hasRole('admin',auth()->user()->role_id) || auth()->user()->hasRole('admin2',auth()->user()->role_id)): ?>
                                        <th class="all">تعيين باحث مساعد</th>
                                        <th class="all">خيارات.</th>
                                    <?php endif; ?>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $searchs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $search): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td> <?php echo e($search->searcher->Code); ?></td>
                                    <td><?php echo e($search->searcher->Fistname); ?> <?php echo e($search->searcher->LastName); ?></td>
                                    <td>
                                        <a   href="<?php echo e(route('getOneSearch',$search->ID)); ?>">
                                        <?php echo e($search->Name); ?>

                                        </a>
                                    </td>
                                     <td><?php echo e($search->division->Name); ?></td>


                                     <td>
                                        <a href="<?php echo e(url('storage/searchs/'.$search->SearchURL)); ?>" >تحميل</a>
                                    </td>


                                   


                                    <?php if(auth()->user()->hasRole('admin2',auth()->user()->role_id) || auth()->user()->hasRole('admin',auth()->user()->role_id)): ?>
                                   <td>
                                       <a  data-toggle="modal" data-target="#exampleModal<?php echo e($search->ID); ?>">
                                           <i class="fa fa-check-square-o"></i> تعيين / إلغاء تعيين </a>
                                       <div class="modal fade" id="exampleModal<?php echo e($search->ID); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                           <div class="modal-dialog" role="document">
                                               <div class="modal-content">
                                                   <form method="POST" action="<?php echo e(route('addSearchReviewer')); ?>">
                                                       <?php echo e(csrf_field()); ?>



                                                       <div class="modal-header">
                                                           <h5 class="modal-title" id="exampleModalLabel">المراجعين</h5>
                                                           <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                               <span aria-hidden="true">&times;</span>
                                                           </button>
                                                       </div>
                                                       <div class="modal-body">
                                                           <input type="hidden" name="searchid" value="<?php echo e($search->ID); ?>"/>
                                                           <div class="form-group">
                                                               <label class="col-md-4">لائحة المراجعين :</label>
                                                               <select class="col-md-8 multiple-checkboxes form-control" name="reviewers[]" multiple="multiple">


                                                                   <?php
                                                                   $isAssigned = false;
                                                                   $arr = array();
                                                                   foreach($search->reviewerSearch as $rev)
                                                                   {
                                                                       array_push($arr,$rev->reviewer);
                                                                   }
                                                                   ?>

                                                                   <?php $__currentLoopData = $reviewers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rev): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                       <option value="<?php echo e($rev->id); ?>" <?php if(in_array($rev->id,$arr)): ?> selected <?php  $isAssigned = true;  ?> <?php endif; ?>><?php echo e($rev->Fistname); ?> <?php echo e($rev->LastName); ?></option>
                                                                   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                                               </select>
                                                           </div>
                                                       </div>
                                                       <div class="modal-footer">
                                                           <button type="button" class="btn btn-secondary" data-dismiss="modal">اغلاق</button>
                                                           <button type="submit" class="btn btn-primary">حفظ التعديلات</button>
                                                       </div>
                                                   </form>
                                               </div>
                                           </div>
                                       </div>
                                       <?php if(!$isAssigned): ?>
                                             <span class="badge badge-danger"> لم يتم تعيين باحث مساعد </span>
                                       <?php endif; ?>

                                   </td>

                                    <td>
                                        <a   href="<?php echo e(route('getOneSearch',$search->ID)); ?>">
                                            <i class="fa fa-search"></i> اظهار البحث </a>

                                    </td>
                                    <?php endif; ?>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>


        </div>
</div>
        <!-- END CONTENT BODY -->
    </div>
    <!-- END CONTENT -->
    <?php $__env->startSection('pageScript'); ?>
        <!-- BEGIN PAGE LEVEL PLUGINS -->
        <script src="<?php echo asset('assets/global/scripts/datatable.js'); ?>" type="text/javascript"></script>
        <script src="<?php echo asset('assets/global/plugins/datatables/datatables.min.js'); ?>" type="text/javascript"></script>
        <script src="<?php echo asset('assets/global/plugins/datatables/plugins/bootstrap/datatables.bootstrap.js'); ?>" type="text/javascript"></script>
         <script src="<?php echo asset('assets/pages/scripts/table-datatables-responsive.min.js'); ?>" type="text/javascript"></script>
         <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-multiselect/0.9.13/js/bootstrap-multiselect.js"></script>
       
        <script type="text/javascript">
            $(document).ready(function() {
                $('.multiple-checkboxes').multiselect({
                    nonSelectedText:'لا مراجع',
                    allSelectedText: 'الكل',

                });
            });
        </script>
        <!-- END PAGE LEVEL PLUGINS -->
    <?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>