
<pre dir="rtl" style="Float:right;"><strong><?php echo e($text); ?></strong></pre>
