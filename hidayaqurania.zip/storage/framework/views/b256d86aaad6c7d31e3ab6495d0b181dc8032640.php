<!DOCTYPE html>

<html lang="en" dir="rtl">

    <head>
        <meta charset="utf-8" />
        <title>تسجيل الدخول</title>
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta content="width=device-width, initial-scale=1" name="viewport" />
        <meta content="البوابة الالكترونية لموسوعة الهدايات القرآنية" name="description" />
        <meta content="" name="author" />
         <link href="<?php echo asset('assets/global/plugins/font-awesome/css/font-awesome.min.css'); ?>" rel="stylesheet" type="text/css" />
        <link href="<?php echo asset('assets/global/plugins/simple-line-icons/simple-line-icons.min.css'); ?>" rel="stylesheet" type="text/css" />
        <link href="<?php echo asset('assets/global/plugins/bootstrap/css/bootstrap-rtl.min.css'); ?>" rel="stylesheet" type="text/css" />
        <link href="<?php echo asset('assets/global/plugins/bootstrap-switch/css/bootstrap-switch-rtl.min.css'); ?>" rel="stylesheet" type="text/css" />
        <link rel="stylesheet" type="text/css" href="//www.fontstatic.com/f=droid-sans" />

        <link href="<?php echo asset('assets/global/plugins/select2/css/select2.min.css'); ?>" rel="stylesheet" type="text/css" />
        <link href="<?php echo asset('assets/global/plugins/select2/css/select2-bootstrap.min.css'); ?>" rel="stylesheet" type="text/css" />
        <!-- END PAGE LEVEL PLUGINS -->
        <!-- BEGIN THEME GLOBAL STYLES -->
        <link href="<?php echo asset('assets/global/css/components-rtl.min.css'); ?>" rel="stylesheet" id="style_components" type="text/css" />
        <link href="<?php echo asset('assets/global/css/plugins-rtl.min.css'); ?>" rel="stylesheet" type="text/css" />
        <!-- END THEME GLOBAL STYLES -->
        <!-- BEGIN PAGE LEVEL STYLES -->
        <link href="<?php echo asset('assets/pages/css/login-rtl.min.css'); ?>" rel="stylesheet" type="text/css" />

        <style>
            @import  url(http://fonts.googleapis.com/earlyaccess/notosanskufiarabic.css);

            body,h1,h2,h3,h4,h5{
                font-family: 'Noto Sans Kufi Arabic', serif;
            }
        </style>

        <!-- END PAGE LEVEL STYLES -->
        <!-- BEGIN THEME LAYOUT STYLES -->
        <!-- END THEME LAYOUT STYLES -->
        <link rel="shortcut icon" href="favicon.ico" /> </head>
    <!-- END HEAD -->