<?php $__env->startSection('pageTitle', 'المصادر التعليمية'); ?>
<?php $__env->startSection('pageStyle'); ?>
    
    <!-- BEGIN PAGE LEVEL PLUGINS -->
    <link href="<?php echo asset('assets/global/plugins/datatables/datatables.min.css'); ?>" rel="stylesheet" type="text/css" />
    <link href="<?php echo asset('assets/global/plugins/datatables/plugins/bootstrap/datatables.bootstrap-rtl.css'); ?>" rel="stylesheet" type="text/css" />
    <!-- END PAGE LEVEL PLUGINS -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('pageTitle', 'الرئيسية'); ?>


<?php $__env->startSection('content'); ?>

    <!-- BEGIN CONTENT -->
    <div class="page-content-wrapper">
        <!-- BEGIN CONTENT BODY -->
        <div class="page-content">
            <!-- BEGIN PAGE HEADER-->


            <div class="page-bar">
                <ul class="page-breadcrumb">
                    <li>
                        <i class="icon-home"></i>
                    <a href="<?php echo e(route('portalwelcome')); ?>">الرئيسية</a>
                        <i class="fa fa-angle-left"></i>
                    </li>
                    <li>
                            <i class="icon-docs"></i>
                        <span>مصادري التعليمية</span>
                    </li>
                </ul>
            </div>
            <!-- END PAGE HEADER-->

         
            <div class="row">
            <div class="col-md-12">
                <!-- BEGIN EXAMPLE TABLE PORTLET-->
                <div class="portlet light ">
                    <div class="portlet-title">
                        <div class="caption font-dark">
                            <i class="icon-graduation font-dark"></i>
                            <span class="caption-subject bold uppercase">لائحة المصادر التعليمية  بالنظام</span>
                        </div>
                        <div class="tools"> </div>
                    </div>
                    <div class="portlet-body">
                        <table class="table table-striped table-bordered table-hover dt-responsive" width="100%" id="sample_1">
                            <thead>
                                <tr>
                                    <th class="all">اسم الكتاب / المرجع</th>
                                    <th class="all">الكاتب</th>
                                    <th class="all">رقم ISBN</th>
                                    <th class="none"> صورة الغلاف</th>
                                    <th class="all">الرابط</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $books; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($book->Name); ?></td>
                                    <td><?php echo e($book->Author); ?></td>
                                    <td><?php echo e($book->ISBN); ?></td>
                                    <td>
                                        <img src="<?php echo e(url('storage/books/'.$book->PictureURL)); ?>" 
                                            style="width: 59%;height: 59%;" class="img-responsive" alt=""> </div>
                                    </td>
                                    <td><a href="<?php echo e($book->URL); ?>">تحميل</a></td>
                                    
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>


        </div>
</div>
        <!-- END CONTENT BODY -->
    </div>
    <!-- END CONTENT -->
    <?php $__env->startSection('pageScript'); ?>
        <!-- BEGIN PAGE LEVEL PLUGINS -->
        <script src="<?php echo asset('assets/global/scripts/datatable.js'); ?>" type="text/javascript"></script>
        <script src="<?php echo asset('assets/global/plugins/datatables/datatables.min.js'); ?>" type="text/javascript"></script>
        <script src="<?php echo asset('assets/global/plugins/datatables/plugins/bootstrap/datatables.bootstrap.js'); ?>" type="text/javascript"></script>
         <script src="<?php echo asset('assets/pages/scripts/table-datatables-responsive.min.js'); ?>" type="text/javascript"></script>
   
        <!-- END PAGE LEVEL PLUGINS -->
    <?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>