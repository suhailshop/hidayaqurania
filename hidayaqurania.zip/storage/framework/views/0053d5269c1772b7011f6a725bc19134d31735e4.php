<?php $__env->startSection('pageTitle', 'تعديل جامعة '); ?>
<?php $__env->startSection('pageStyle'); ?>
    
        <!-- BEGIN PAGE LEVEL PLUGINS -->
        <link href="<?php echo asset('assets/global/plugins/select2/css/select2.min.css'); ?>" rel="stylesheet" type="text/css" />
        <link href="<?php echo asset('assets/global/plugins/select2/css/select2-bootstrap.min.css'); ?>" rel="stylesheet" type="text/css" />
        <link href="<?php echo asset('assets/global/plugins/bootstrap-datepicker/css/bootstrap-datepicker3.min.css'); ?>" rel="stylesheet" type="text/css" />
        <link href="<?php echo asset('assets/global/plugins/bootstrap-wysihtml5/bootstrap-wysihtml5-rtl.css'); ?>" rel="stylesheet" type="text/css" />
        <link href="<?php echo asset('assets/global/plugins/bootstrap-markdown/css/bootstrap-markdown.min.css'); ?>" rel="stylesheet" type="text/css" />
        <!-- END PAGE LEVEL PLUGINS -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('pageTitle', 'الرئيسية'); ?>


<?php $__env->startSection('content'); ?>

    <!-- BEGIN CONTENT -->
    <div class="page-content-wrapper">
        <!-- BEGIN CONTENT BODY -->
        <div class="page-content">
            <!-- BEGIN PAGE HEADER-->


            <h1 class="page-title"> البوابة الالكترونية لموسوعة الهدايات القرآنية

            </h1>
            <div class="page-bar">
                    <ul class="page-breadcrumb">
                        <li>
                            <i class="icon-home"></i>
                             <a href="<?php echo e(route('portalwelcome')); ?>">الرئيسية</a>
                            <i class="fa fa-angle-left"></i>
                        </li>
                        <li>
                                <i class="icon-graduation"></i>
                                 <a href="<?php echo e(route('allUniversity')); ?>">إدارة الجامعات</a>
                                <i class="fa fa-angle-left"></i>
                            </li>
                        <li>
                            <span>تعديل جامعة</span>
                        </li>
                    </ul>
                </div>
            <!-- END PAGE HEADER-->
            <div class="m-heading-1 border-green m-bordered">
                <h3>تعديل معلومات الجامعة </h3>
                <p> المرجو ملء الخانات بالمعلومات الخاصة بالجامعة :
            </div>
<div class="row">
    
<form action="<?php echo e(route('editUniversityPost')); ?>" method="post" id="form_sample_2" class="form-horizontal" enctype="multipart/form-data">
        <?php echo e(csrf_field()); ?>

            <div class="col-md-6">
                    <!-- BEGIN VALIDATION STATES-->
                    <div class="portlet light portlet-fit portlet-form ">
                       
                        
                        <div class="portlet-body">
                            <!-- BEGIN FORM-->
                                <div class="form-body">
                                    <div class="alert alert-danger display-hide">
                                        <button class="close" data-close="alert"></button> لديك بعض الاخطاء في النموذج . يرجى مراجعة أدناه. </div>
                                   
                                        <input type="hidden" value="<?php echo e($universitie->ID); ?>" name="id"/>
                                        <input type="hidden" value="<?php echo e($universitie->Logo); ?>" name="img"/>
                                    <div class="form-group  margin-top-20">
                                       
                                        <div class="col-md-12">
                                                <label>اسم الجامعة</label>
                                            <div class="input-icon right">
                                                <i class="fa"></i>
                                            <input type="text" class="form-control" name="name" value="<?php echo e($universitie->Name); ?>" placeholder="اسم الجامعة *"/> </div>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        
                                        <div class="col-md-12">
                                                <label>الرئيس</label>
                                            <div class="input-icon right">
                                                <i class="fa"></i>
                                                <input type="text" class="form-control" name="president" value="<?php echo e($universitie->President); ?>" placeholder="الرئيس *"/> </div>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        
                                        <div class="col-md-12">
                                                <label>الدولة</label>
                                            <div class="input-icon right">
                                                <i class="fa"></i>
                                                <select  class="form-control" name="countrie" placeholder="الدولة *"/>
                                                <?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $countrie): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option <?php if($universitie->Countrie==$countrie->ID): ?> selected <?php endif; ?> value="<?php echo e($countrie->ID); ?>" ><?php echo e($countrie->Name); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select> </div>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        
                                        <div class="col-md-12">
                                                <label>المدينة</label>
                                            <div class="input-icon right">
                                                <i class="fa"></i>
                                                <input type="text" class="form-control" name="city" value="<?php echo e($universitie->City); ?>" placeholder="المدينة *"/> </div>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                       
                                        <div class="col-md-12">
                                                <label>العنوان</label>
                                            <div class="input-icon right">
                                                <i class="fa"></i>
                                                <input type="text" class="form-control" name="location" value="<?php echo e($universitie->Location); ?>" placeholder="العنوان *" /> </div>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <div class="col-md-12">
                                                <div class="fileinput-new thumbnail img-fluid" style="width: 200px; height: 150px;">
                                                        <img src="<?php echo e(url('storage/universities/'.$universitie->Logo)); ?>" alt="" id="blah" /> </div>
                                        </div>
                                    </div>
                                    <div class="form-group ">
                                            <div class="col-md-12">
                                                    <label>الصورة</label>
                                                <div class="input-icon right">
                                                    <i class="fa"></i>
                                                    <input type="file" class="form-control" name="logo" > </div>
                                            </div>
                                        </div>
                                    
                                    
                                </div>
                                
                            <!-- END FORM-->
                        </div>
                    </div>
                </div>
                <div class="col-md-6">
                    <!-- BEGIN VALIDATION STATES-->
                    <div class="portlet light portlet-fit portlet-form ">
                       
                        
                        <div class="portlet-body">
                            <!-- BEGIN FORM-->
                                <div class="form-body">
                                    
                                    
                                        <div class="form-group margin-top-20">
                                                <div class="col-md-12">
                                                        <label>الهاتف</label>
                                                    <div class="input-icon right">
                                                        <i class="fa"></i>
                                                        <input type="number" class="form-control" name="phonne" value="<?php echo e($universitie->Phonne); ?>" placeholder="الهاتف *" /> </div>
                                                </div>
                                            </div>
                                    <div class="form-group ">
                                        <div class="col-md-12">
                                                <label>الفاكس</label>
                                            <div class="input-icon right">
                                                <i class="fa"></i>
                                                <input type="number" class="form-control" name="fax" value="<?php echo e($universitie->Fax); ?>"  placeholder="الفاكس *" /> </div>
                                        </div>
                                    </div>
                                   
                                    <div class="form-group">
                                        <div class="col-md-12">
                                                <label>البريد الالكتروني</label>
                                            <div class="input-icon right">
                                                <i class="fa"></i>
                                                <input type="email" class="form-control" name="email" value="<?php echo e($universitie->Email); ?>" placeholder="البريد الاكتروني *" /> </div>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <div class="col-md-12">
                                                <label>رقم العقدة</label>
                                            <div class="input-icon right">
                                                <i class="fa"></i>
                                                <input type="number" class="form-control" name="contratid" value="<?php echo e($universitie->ContractID); ?>" placeholder="رقم العقدة *" /> </div>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <div class="col-md-12">
                                                <label>تاريخ العقدة</label>
                                            <div class="input-icon right">
                                                <i class="fa"></i>
                                                <input type="date" class="form-control" name="contratdate" value="<?php echo e($universitie->ContractDate); ?>" placeholder="تاريخ العقدة" /> </div>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                            
                                            <div class="col-md-12">
                                                    <label>الحالة</label>
                                                <div class="input-icon right">
                                                    <i class="fa"></i>
                                                    <select  class="form-control" name="status" placeholder="الحالة *"/>
                                                    
                                                        <option <?php if($universitie->Status=='yes'): ?> selected <?php endif; ?> value="yes" >مفعلة</option>

                                                        <option <?php if($universitie->Status=='no'): ?> selected <?php endif; ?> value="no" >غير مفعلة</option>
                                                    </select> </div>
                                            </div>
                                        </div>
                                    <div class="form-actions">
                                            <div class="row">
                                                <div class="col-md-offset-3 col-md-9">
                                                    <button type="submit" class="btn green">تأكيد</button>
                                                    <button type="reset" class="btn default">الغاء</button>
                                                </div>
                                            </div>
                                        </div>
                                    
                                </div>
                                
                            </form>
                            <!-- END FORM-->
                        </div>
                    </div>
                </div>
                    <!-- END VALIDATION STATES-->
                </div>



        </div>
        <!-- END CONTENT BODY -->
    </div>
    <!-- END CONTENT -->
    <?php $__env->startSection('pageScript'); ?>
    <!-- BEGIN PAGE LEVEL PLUGINS -->
    <script src="<?php echo asset('assets/global/plugins/select2/js/select2.full.min.js'); ?>" type="text/javascript"></script>
    <script src="<?php echo asset('assets/global/plugins/jquery-validation/js/jquery.validate.min.js'); ?>" type="text/javascript"></script>
    <script src="<?php echo asset('assets/global/plugins/jquery-validation/js/additional-methods.min.js'); ?>" type="text/javascript"></script>
    <script src="<?php echo asset('assets/global/plugins/bootstrap-datepicker/js/bootstrap-datepicker.min.js'); ?>" type="text/javascript"></script>
    <script src="<?php echo asset('assets/global/plugins/bootstrap-markdown/lib/markdown.js'); ?>" type="text/javascript"></script>
    <script src="<?php echo asset('assets/global/plugins/bootstrap-markdown/js/bootstrap-markdown.js'); ?>" type="text/javascript"></script>
    <!-- END PAGE LEVEL PLUGINS -->
     <!-- BEGIN PAGE LEVEL SCRIPTS -->
     <script src="<?php echo asset('assets/pages/scripts/form-validation.min.js'); ?>" type="text/javascript"></script>
     <!-- END PAGE LEVEL SCRIPTS -->
    <?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>